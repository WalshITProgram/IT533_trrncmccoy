from bs4 import BeautifulSoup
from xml.dom import minidom
import os 

my_file = open("text_files/employee_data.xml")