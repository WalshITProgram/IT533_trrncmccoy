import json
from Classes.appclass import *

App()
 